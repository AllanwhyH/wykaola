function task(){



    if(){

    }else{

    }
}
var timer=setInterval(task,3000);
